# Código de Conducta

Queremos que este proyecto sea un lugar agradable para todos.

- Sé respetuoso con los demás.
- No uses lenguaje ofensivo ni discriminatorio.

Si tienes algún problema, contáctame para resolverlo.
